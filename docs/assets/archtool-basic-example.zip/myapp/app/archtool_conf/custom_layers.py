from archtool.global_types import AppModule
from archtool.layers.default_layers import default_layers

APPS = [
    AppModule("app.users"),
]

app_layers = default_layers
