from .interfaces import UserServiceABC, UserRepoABC


class UserService(UserServiceABC):
    repo: UserRepoABC  # archtool sets this automatically

    def get_name(self) -> str:
        return self.repo.find_all()[0]
