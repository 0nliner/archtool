from pathlib import Path
from archtool.dependency_injector import DependencyInjector
from app.archtool_conf.custom_layers import APPS, app_layers

ROOT = Path(__file__).parent.parent


def test_di_assembles():
    injector = DependencyInjector(
        modules_list=APPS,
        layers=app_layers,
        project_root=ROOT,
    )
    injector.inject()
